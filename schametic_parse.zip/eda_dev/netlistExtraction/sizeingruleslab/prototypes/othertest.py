
import itertools


# a = [1, 2, 3]
a = [i for i in range (0, 10)]
b = itertools.combinations(a, 2)  # 含有两个元素的组合
for bi in b:  # 或 print(list(b))
    print(bi)