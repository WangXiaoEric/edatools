from netlistExtraction.sizeingruleslab.prototypes.block import Block
import os

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class ScmNmos(Block):



    currentDir = os.path.dirname(__file__)
    #Slolution2
    subCircuit = fetchInstances(netlist_dir=currentDir)

    mDict = {}
    mDict = {"M1": convertFromRawModule([subCircuit.elements[0]]), "M2": convertFromRawModule([subCircuit.elements[1]])}
    G = convertFromRawModule(subCircuit.elements).G  #当前层级的G

    ruleName = "ScmNmos"
    M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])

    print("ScmNmos initialized ...")

    def __init__(self):
        self.isBankable = True
        super().__init__()

