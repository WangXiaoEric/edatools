import time

from netlistExtraction.demo_test import parse_schematic, dominator_filter
from netlistExtraction.sizeingruleslab.entryutil import initAllSizingRules, print_final_M

if __name__ == "__main__":

    start_time = time.time()

    # netlist_dir = 'examples_netlist2graph/dai_diffopamp/'
    netlist_dir = 'examples_netlist2graph/6TOPAMP'
    # netlist_dir = 'examples_netlist2graph/dai_twostageopampnocc/'

    # 初始化所有的Sizing Rules
    curentSizingRules = initAllSizingRules()
    Res1, Res2, targetM = parse_schematic(netlist_dir, curentSizingRules)

    ###
    # print_final_M(targetM)
    # printRes1_2(Res1, Res2)
    ###

    ###
    Final_M = dominator_filter(Res1, Res2, targetM)
    print_final_M(Final_M)
    ##

    ## 在添加一步骤 去除中间重复与被包含的内容，成为一个版本；

    end_time = time.time()
    print("Time cost is : {:.2f}s".format(end_time - start_time))