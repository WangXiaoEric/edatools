from matplotlib.font_manager import FontProperties
import matplotlib.pyplot as plt
import networkx as nx

# myfont = FontProperties(fname=r"C:\Windows\Fonts\STXINGKA.TTF", size=20)  # fname指定字体文件  选简体显示中文

# 定义图的节点和边
nodes = ['0', '1', '2', '3', '4', '5', 'a', 'b', 'c']
edges = [('0', '0', 1), ('0', '1', 1), ('0', '5', 1), ('0', '5', 2), ('1', '2', 3), ('1', '4', 5), ('2', '1', 7),
         ('2', '4', 6), ('a', 'b', 0.5), ('b', 'c', 0.5), ('c', 'a', 0.5)]

plt.subplots(1, 2, figsize=(10, 3))


G2 = nx.DiGraph()
G2.add_nodes_from(nodes)
G2.add_weighted_edges_from(edges)

nx.bidirectional_dijkstra

path = nx.bidirectional_dijkstra(G2,'2','0')
print(path)
haspath = nx.has_path(G2,'0','2')
print(haspath)

print()
# pos2 = nx.circular_layout(G2)

# plt.subplot(122)
# nx.draw(G2, pos2, with_labels=True, font_weight='bold')
# plt.title('有向图')
# # plt.axis('on')
# plt.xticks([])
# plt.yticks([])
#
# plt.show()