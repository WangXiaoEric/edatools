import os

from netlistExtraction.sizeingruleslab.prototypes.block import Block

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class FtcmPmos(Block):
    """
    M1 为VR1
    M2 为CML
    """

    currentDir = os.path.dirname(__file__)
    # Slolution2
    subCircuit = fetchInstances(netlist_dir=currentDir)


    mDict = {}
    ruleName = "FtcmPmos"

    mDict = {"M1": convertFromRawModule(subCircuit.elements[0:2]), "M2": convertFromRawModule(subCircuit.elements[2:4])}
    # [0:2] 为 VR1, [2:4] 为CML

    G = convertFromRawModule(subCircuit.elements).G

    M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])
    print("FtcmPmos initialized ...")

    def __init__(self):
        super().__init__()
