from netlistExtraction.sizeingruleslab.prototypes.BaseSizeModel import BaseSizeModel
from netlistExtraction.sizeingruleslab.prototypes.DominateRelation import DominateRelation
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2, filterM, \
    topologyAlreadyIN, namePairAlreadyIN, isSizingRuleSomorphic, bankGroupAndCombine, findClosure, mInList, \
    baseSizeListIntersection, filterInF, removeInL1byL2
from sizeingruleslab.entryutil import *
import networkx as nx
import matplotlib.pyplot as plt
import itertools
from netlistExtraction.sizeingruleslab.prototypes.alignschematic import *
import time
import copy
import itertools as it


def parse_schematic(netlist_dir, curentSizingRules):
    # 目标匹配电路
    targetCircuit = fetchInstances(netlist_dir=netlist_dir)

    # 随着识别出来的module进行扩容
    targetM = [convertFromRawModule([ele]) for ele in targetCircuit.elements]


    # 最终结果 Line 2
    Res1 = []
    Res2 = []
    # TODO 应该从TargetM终结开始考虑
    # 这里是一个排列问题， 分顺序；  Line 3
    for rule in curentSizingRules:  # line 4在rule初始化的时候即完成

        # 对DS L3的特殊处理，不进行Graph子图匹配, 只进行特殊点关联
        if rule.ruleName == "DsNmos":  # 对Level3 的 DsNmos处理
            targetM = rule.populateDs(targetM, Res1, Res2)
            continue

        candidateM1List = filterM(rule.mDict.get("M1"), targetM)
        candidateM2List = filterM(rule.mDict.get("M2"), targetM)

        curRuleMapping = []
        curRes1 = []
        curRes2 = []
        # 这里面要过滤一下只能保留与C1中类型一致的
        for m_pos1 in candidateM1List:  # Line 5
            for m_pos2 in candidateM2List:
                # 判断名字是否相等
                if m_pos1.names == m_pos2.names:  # Line6
                    continue  # 不考虑两个M相同的情形
                # if pos1.model != rule.pos_1Type or pos2.model != rule.pos_2Type:
                #     continue #两个M与Sizing Rule的Type不一致的情形  Type在filterM函数中已经过滤

                G_M1_M2 = combineM1M2(m_pos1, m_pos2)  # Line7 在这里其实端点与Pin角是联通的

                # is_isomorphic = nx.vf2pp_is_isomorphic(rule.G, G_M1_M2.G, node_label=None)
                is_isomorphic = isSizingRuleSomorphic(rule, G_M1_M2)  # Line 8
                if is_isomorphic:  # MN11与MN5被错误匹配为DP对；

                    if (namePairAlreadyIN(G_M1_M2, targetM,
                                          curRuleMapping)):  # 1 互相对称的问题后面可以处理 因为本身就存在重复   2 添加了curRuleMapping 同时targetM 与 curRuleMapping都没有的情况下
                        # 过滤 防止对称pair的出现情形
                        continue
                    else:
                        # 测试数据
                        # map = nx.vf2pp_isomorphism(rule.G, G_M1_M2.G, node_label=None)
                        # print("pos1.name:" + ' '.join(m_pos1.names))
                        # print("pos2.name:" + ' '.join(m_pos2.names))
                        # nx.draw(G_M1_M2.G, with_labels=True)
                        # plt.show()
                        # print(map)
                        # 测试数据

                        G_M1_M2.ruleNameMapped = rule.ruleName
                        G_M1_M2.isBankable = rule.isBankable
                        curRuleMapping.append(G_M1_M2)  # 当前的rule对应的
                        # targetM.append(G_M1_M2)  # Line9 Line 10 Line11 与 Line12   直接 append 原生的电路图的资料到网络图中
                        # targetM.append(rule.M1_M2)  # Line13 后面应该 TODO 考虑到底是append rule的还是append 电路里面的
                        # Res1.append([m_pos1, G_M1_M2])  # Line14
                        # Res2.append([m_pos2, G_M1_M2])  # Line15
                        curRes1.append([m_pos1, G_M1_M2])
                        curRes2.append([m_pos2, G_M1_M2])
                        # print(m_pos1)

        # targetM = targetM + curRuleMapping
        # Res1 = Res1 + curRes1
        # Res2 = Res2 + curRes2

        # 考虑是否对bankable的组件进行特殊处理；
        # 把不需要做bankable合并的先过滤出来，先进行操作了
        curRuleMapping_unbankable = []
        curRes1_unbankable = []
        curRes2_unbankable = []

        # 需要做bankable合并的先过滤出来，后进行操作了
        curRuleMapping_bankable = []
        curRes1_bankable = []
        curRes2_bankable = []

        # unbankable 与 bankable分离处理
        for idx, tempRuleMapping in enumerate(curRuleMapping):
            if tempRuleMapping.isBankable:
                curRuleMapping_bankable.append(tempRuleMapping)
                curRes1_bankable.append(curRes1[idx])
                curRes2_bankable.append(curRes2[idx])
            else:
                curRuleMapping_unbankable.append(tempRuleMapping)
                curRes1_unbankable.append(curRes1[idx])
                curRes2_unbankable.append(curRes2[idx])

        # 先将unbankable统计进入结果中来
        targetM = targetM + curRuleMapping_unbankable
        Res1 = Res1 + curRes1_unbankable
        Res2 = Res2 + curRes2_unbankable

        if curRuleMapping_bankable:
            # 原始的也加上  TODO 原先是删除的
            targetM = targetM + curRuleMapping_bankable
            Res1 = Res1 + curRes1_bankable
            Res2 = Res2 + curRes2_bankable

            # 合并bankable.  用convertFromRawModule 将群众pair组件起来， 用combine不断去组装起来；
            curRuleMapping_bankable_merged, curRes1_bankable_merged, curRes2_bankable_merged = bankGroupAndCombine(
                curRuleMapping_bankable, curRes1_bankable, curRes2_bankable, rule)
            targetM = targetM + curRuleMapping_bankable_merged
            Res1 = Res1 + curRes1_bankable_merged
            Res2 = Res2 + curRes2_bankable_merged

    return Res1, Res2, targetM

def dominator_filter(Res1, Res2, targetM):
    Final_M = copy.deepcopy(targetM)  # Line1
    R_plus = Res1 + Res2  # # Line1
    R_combine = [Res1, Res2]
    for M in targetM: # line2
        if mInList(M, Final_M):  #line3
            E = findClosure(M, R_plus)  #Line4  TODO 还需要再F中进行Filter.
            E = filterInF(E, Final_M)
            # U = list(it.combinations(E, 2))  # Line5 根据R+， 找到闭包，然后再进行组合， 相当于得到的是一个个的M pair.  U的作用是展开所有可能
            U = list(it.permutations(E, 2))  # Line5 根据R+， 找到闭包，然后再进行组合， 相当于得到的是一个个的M pair.  U的作用是展开所有可能
            #求Res的闭包线之后，
            for i, R_i in enumerate(R_combine):
                for j, R_j in enumerate(R_combine): # 135 and 135 为Line6 共计四种情况
                    u_list = baseSizeListIntersection(R_i, U)  # line 7
                    for u in u_list:  # line 7
                        # print()
                        v_list = baseSizeListIntersection(R_j, U)
                        for v in v_list:  #  # line 8 还要减去与一个u 可以放在下一行，如果v = u 则不做处理
                            # 如果v = u 则不做任何处理 line 8, 减掉u的操作
                            if u[0].names == v[0].names and u[0].ruleNameMapped == v[0].ruleNameMapped and u[1].names == v[1].names and u[1].ruleNameMapped == v[1].ruleNameMapped:
                                continue
                            else:
                                domance_item = (    (u[1].ruleNameMapped, (i + 1)),      (v[1].ruleNameMapped, (j + 1))     ) #随着i 与 j的变化 是 左左 左右 右左 右右
                                if DominateRelation.nominalIn(domance_item):  # Line 9  可以通过再这里添加断电，然后反向去添加rule
                                    Final_M = removeInL1byL2(Final_M,  list(findClosure(u[1], R_plus)) ) # 算法核心 闭包中任意两组组合， 后面的强于前面的， 前面的闭包全部干掉
                                    # 再做一个过滤， 同时将Nmos与Pmos删除掉即可。



            # Line9  Donimance 并不是一个Tree 只是一个关系。  这部分的算法设计，取决于Domanance Tree的设计方式。 这个Tree的设计方式
            # Line9 此行既包含不同domanance level的资料， 也包含不同hirarchy的资料
    return Final_M

if __name__ == "__main__":

    start_time = time.time()

    netlist_dir = 'examples_netlist2graph/22tOpAmp/'
    # 初始化所有的Sizing Rules
    curentSizingRules = initAllSizingRules()
    Res1, Res2, targetM = parse_schematic(netlist_dir, curentSizingRules)

    ###
    # print_final_M(targetM)
    # printRes1_2(Res1, Res2)
    ###

    ###
    Final_M = dominator_filter(Res1, Res2, targetM)
    print_final_M(Final_M)
    ##

    ## 在添加一步骤 去除中间重复与被包含的内容，成为一个版本；

    end_time = time.time()
    print("Time cost is : {:.2f}s".format(end_time - start_time))



