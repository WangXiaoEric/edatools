# rm -rf build
# mkdir build
cd build
cmake ..
make -j4
make install