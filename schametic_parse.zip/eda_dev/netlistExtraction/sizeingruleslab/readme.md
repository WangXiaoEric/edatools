###
support both nmos and pmos.
###
currently only support four parameter format with 'b'
like 
.subckt SCM_NMOS_B DA DB S B

not support
.subckt SCM_NMOS DA DB S