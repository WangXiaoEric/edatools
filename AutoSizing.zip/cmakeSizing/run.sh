
./build/bin/analogsizing 