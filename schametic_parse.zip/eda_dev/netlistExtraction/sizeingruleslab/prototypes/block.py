class Block:
    isBuildingBlock = False
    allowedTypes = False
    isBankable = False
    def __init__(self):

        return
