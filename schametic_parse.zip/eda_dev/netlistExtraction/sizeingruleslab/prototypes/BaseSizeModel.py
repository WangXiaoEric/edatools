from netlistExtraction.sizeingruleslab.prototypes.block import Block
from netlistExtraction.sizeingruleslab.prototypes.model_block import ModelBlock


class BaseSizeModel(ModelBlock):

    def __init__(self, types=[], names=[], G=None, rawElements=[], ruleNameMapped=None, names_pins = [], names_graphs=[]):
        # G field永远是一个
        self.G = G
        # type是一个list
        self.types = types
        # Name也是一个List
        self.names = names
        # rawElements也是个list
        self.rawElements = rawElements

        self.ruleNameMapped = ruleNameMapped

        self.names_pins = names_pins  # 存储name与PIN(G_D_S_B) Name序列 数据格式为 {M_name, []}

        self.names_graphs = names_graphs  # 存储name与subGraph(G_D_S_B)序列 数据格式为 {M_name, []}  存储的都是Node信息， 在匹配的时候根据Node列表生成Graph
    # 下面定义了一个say方法
    def __str__(self):
        return " ".join(self.names)