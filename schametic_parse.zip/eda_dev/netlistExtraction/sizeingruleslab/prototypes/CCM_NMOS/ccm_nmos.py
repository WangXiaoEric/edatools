import os

from netlistExtraction.sizeingruleslab.prototypes.block import Block

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class CcmNmos(Block):
    """上面是LS 下面是 CM， 所以直接从LS与CM中获取即可
    每一层都有其Graph, 而数据结构也是支持Hirarchy的。
    关键就是这个层次里面的数据结构不太好设计， 看M0 - M3是如何进行排序
    """

    currentDir = os.path.dirname(__file__)
    # Slolution2
    subCircuit = fetchInstances(netlist_dir=currentDir)


    mDict = {}
    ruleName = "CcmNmos"

    # scm_nmos = ScmNmos()
    # ls_nmos = LsNmos()
    # mDict = {"M1": scm_nmos.M1_M2, "M2": ls_nmos.M1_M2}

    mDict = {"M1": convertFromRawModule(subCircuit.elements[0:2]), "M2": convertFromRawModule(subCircuit.elements[2:4])}
    # [0:2] 为 ScmNmos, [2:4] 为 LsNmos

    G = convertFromRawModule(subCircuit.elements).G
    # TODO G的生成问题如何形成， 方案1 目前方案因为Pin角不一样，所以无法形成  所以先手动画一个出来  目前采用这种方案
    # 方案2 从ScmNmos 与  LsNmos自动化拼接 ？ 可能多少会有问题
    # 考虑点： 每一个level 都应该保持一致，并且形成hirarchy结构
    # TODO 看这个图如何而来，这是个问题；

    M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])
    print("CcmNmos initialized ...")

    def __init__(self):
        self.isBankable = True
        super().__init__()
