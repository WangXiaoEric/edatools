from networkx.algorithms import isomorphism
import networkx as nx

#
#
# G1 = nx.path_graph(4)
# G2 = nx.path_graph(8)
# GM = isomorphism.GraphMatcher(G1, G2)
# result = GM.is_isomorphic()

G = nx.path_graph(4)  # or DiGraph, MultiGraph, MultiDiGraph, etc
G1 = G.subgraph([0, 1, 2])
G2 = G.subgraph([1, 2, 3])

is_isomorphic = nx.vf2pp_is_isomorphic(G2, G1, node_label=None)
print(is_isomorphic)
map = nx.vf2pp_isomorphism(G1, G2, node_label=None)
print("===")


