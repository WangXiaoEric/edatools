from pathlib import Path

import pandas as pd


df = pd.DataFrame(data = {"hour":range(1,101)})


output_file = '/tmp/long_path/to/my_dir/my_file.csv'
output_file_path = Path(output_file)
output_file_path.parent.mkdir(parents=True, exist_ok=True)

df.to_csv(output_file)