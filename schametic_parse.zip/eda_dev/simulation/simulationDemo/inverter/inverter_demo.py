from simulation.ngspiceentry import *

ngsim(sim_file ="C:/Users/ericwang/PycharmProjects/eda_dev/simulation/simulationDemo/inverter/bsimbulk_inverter.sp")