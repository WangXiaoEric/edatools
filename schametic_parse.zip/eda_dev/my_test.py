import torch
import numpy as np

input = torch.from_numpy(np.random.rand(561,8))
weight = torch.from_numpy(np.random.rand(8,64))
bias = torch.from_numpy(np.random.rand(64,1))
res = torch.nn.functional.linear(input, weight, bias=None)
print(res)
