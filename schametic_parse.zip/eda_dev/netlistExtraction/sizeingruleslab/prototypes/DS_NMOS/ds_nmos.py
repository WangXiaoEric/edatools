from netlistExtraction.sizeingruleslab.prototypes.block import Block
import os

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class DsNmos(Block):
    """
       思路1： 动态做成字符来进行匹配
           DS的匹配是一个动态的匹配过程
           能够看现有的有多少个数，然后来组装自己的规则；

           步骤1： 看现有的SCM有哪些 然后拼装一个SP文件。 然后再生成网络
           步骤2：

        思路2：
            直接判断几个关键连接点是否　联通；

    """

    # currentDir = os.path.dirname(__file__)
    #Slolution2
    # subCircuit = fetchInstances(netlist_dir=currentDir)

    # mDict = {}
    # mDict = {"M1": convertFromRawModule([subCircuit.elements[0]]), "M2": convertFromRawModule([subCircuit.elements[1]])}
    # G = convertFromRawModule(subCircuit.elements).G  #当前层级的G

    ruleName = "DsNmos"
    # M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])

    print("DsNmos initialized ...")

    def __init__(self):
        self.ruleName = "DsNmos"
        self.isBankable = True
        super().__init__()

    def populateDs(self, targetM, Res1, Res2):
        dp_group = []
        cm_group = []
        ds_targetM = []




        for item in targetM:
            # if item.ruleNameMapped is not None:
            #     print(item.ruleNameMapped)
            #     print(item.names)
            if item.ruleNameMapped == "DpNmos":
                dp_group.append(item)
            elif item.ruleNameMapped in ["ScmNmos", "CcmNmos"]:
                cm_group.append(item)
        for dp in dp_group:
            for cm in cm_group: #判断条件为  DP的尾步。
                print()  # {'MN8P2', 'MN8P3', 'NET55', 'MN7P3', 'MN7P2'}
                #取DP的第一个的S级进行比较
                dp_pin = dp.names_graphs[0][2]
                cm_pin_set = []
                if len(cm.names) == 2:
                    cm_pin_set.append(cm.names_graphs[1][0])
                elif len(cm.names) == 3:
                    for temp in cm.names_graphs[1:]: # Lst[ Initial : End : IndexJump]  直接采用切片 绕过第一个
                        cm_pin_set.append(temp[0])
                elif len(cm.names) == 4:
                    #如果四个晶体管， 则取第二个晶体管的D级进行比较
                    cm_pin_set.append(cm.names_graphs[1][0])
                    #对于六个晶体管 以及以上的bank数组  可以参考 connect_imgae.png
                else:
                    for temp in cm.names_graphs[2::2]: # Lst[ Initial : End : IndexJump]  直接采用切片 绕过第一个
                        cm_pin_set.append(temp[0])
                # CM 为 m * n的矩阵 （m is 1 or 2）  DP的尾部部 需要要与CM的第一行非第一个元素相连那就OK
                # 取CM的第一行非第一个元素进行比较

                # 如果dp_set 与 cm_set 中有相同的节点， 则判定为连接
                for cm_pin in cm_pin_set:
                    if dp_pin & cm_pin:
                        M1_M2 = combineM1M2(dp, cm)
                        # M1_M2.ruleNameMapped = key
                        M1_M2.ruleNameMapped = self.ruleName
                        ds_targetM.append(M1_M2)
                        Res1.append([dp, M1_M2])
                        Res2.append([cm, M1_M2])

        print("")
        targetM = targetM + ds_targetM
        return targetM

