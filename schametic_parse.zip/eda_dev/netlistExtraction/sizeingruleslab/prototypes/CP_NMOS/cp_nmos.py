import os

from netlistExtraction.sizeingruleslab.prototypes.block import Block

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class CpNmos(Block):
    mDict = {}
    ruleName = "CpNmos"

    currentDir = os.path.dirname(__file__)
    subCircuit = fetchInstances(netlist_dir=currentDir)

    mDict = {"M1": convertFromRawModule([subCircuit.elements[0]]), "M2": convertFromRawModule([subCircuit.elements[1]])}
    G = convertFromRawModule(subCircuit.elements).G

    M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])

    print("LsNmos initialized ...")


    def __init__(self):
        super().__init__()
