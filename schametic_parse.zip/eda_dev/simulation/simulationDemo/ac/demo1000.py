from simulation.ngspiceentry import *
from datetime import datetime

start = datetime.now()



for i in range(0, 1000):
    ngsim(sim_file ="C:/Users/ericwang/PycharmProjects/eda_dev/simulation/simulationDemo/ac/ac.sp")

end = datetime.now()

print("1000 circuit NGSPICE simulation Time:")
print("Start Time:")
print(start)
print("End Time:")
print(end)
