## Fully differential Telescopic OTA

The diagram of the circuit is as follows.
![Circuit diagram](schematic.PNG)
