import matplotlib.pyplot as plt
import networkx as nx

class DominateRelation(object):
    """按照整个 Dominate Grip 由下到上， 先1 后2 统计出来
        并且右边dominate 左边

        用有向图来表达顺序
    """
    all_relation = []
    all_relation.append( (("Dp", 1), ("Cml", 1)) )
    all_relation.append( ( ("Dp", 1), ("Ls", 2)) )
    all_relation.append((("Dp", 2), ("Cml", 1)))
    all_relation.append((("Dp", 2), ("Ls", 2)))
    all_relation.append((("Ls", 2), ("Scm", 2)))
    all_relation.append(( ("Scm", 2), ("Wcm", 1)))
    all_relation.append(( ("Scm", 2), ("Wsccm", 2)))
    all_relation.append(( ("Scm", 2), ("Cml", 2)))
    all_relation.append((("Cml", 1), ("Vr1", 2)))
    all_relation.append((("Cml", 2), ("Vr1", 2)))
    all_relation.append((("Vr1", 2), ("Vr2", 1)))
    all_relation.append((("Vr1", 2), ("Vr2", 2)))
    all_relation.append((("Vr2", 1), ("Cc", 1)))
    all_relation.append((("Vr2", 1), ("Cc", 2)))
    all_relation.append((("Vr2", 2), ("Cc", 1)))
    all_relation.append((("Vr2", 2), ("Cc", 2)))

    # Ccm_2 added by Eric 后来发现添加错了。 这个不能乱添加 CCM如果domanite了SCM 那么一个SCM R+操作了以后， 必定删除CCM
    # TODO SCM 与自身 CCM的问题， 则用包含可以解决，如果包含的话那么直接删除被子集即可；
    nodes = ['Dp_1', 'Cml_1', 'Ls_2', 'Dp_2', 'Scm_2', 'Cml_2', 'Wcm_1', 'Wsccm_2', 'Vr1_2', 'Vr2_1', 'Vr2_2', 'Cc_1', 'Cc_2']
    edges = [('Dp_1', 'Cml_1'), ('Dp_1', 'Ls_2'), ('Dp_2', 'Cml_1'), ('Dp_2', 'Ls_2'),
             ('Ls_2', 'Scm_2'),
             ('Scm_2', 'Wcm_1'), ('Scm_2', 'Wsccm_2'), ('Scm_2', 'Cml_2'),
             ('Cml_1', 'Vr1_2'), ('Cml_2', 'Vr1_2'),
             ('Vr1_2', 'Vr2_1'), ('Vr1_2', 'Vr2_2'),
             ('Vr2_1', 'Cc_1'), ('Vr2_1', 'Cc_2'), ('Vr2_2', 'Cc_1'), ('Vr2_2', 'Cc_2')]
    G2 = nx.DiGraph()  # Direct Graph来做匹配
    G2.add_nodes_from(nodes)
    G2.add_edges_from(edges)

    # pos2 = nx.circular_layout(G2)
    #
    # plt.subplot(122)
    # nx.draw(G2, pos2, with_labels=True, font_weight='bold')
    # plt.title('有向图')
    # # plt.axis('on')
    # plt.xticks([])
    # plt.yticks([])
    #
    # plt.show()
    # print()

    def __init__(self):
        return

    @classmethod
    def nominalIn(self, pair_relate):
        """重点需要处理一下Cp的数值， 看原来文章中Cp是否为默认的情形"""
        pair_relate = ( (pair_relate[0][0].replace("Nmos", "").replace("Pmos", ""), pair_relate[0][1])  ,
                       (pair_relate[1][0].replace("Nmos", "").replace("Pmos", ""), pair_relate[1][1]))

        if pair_relate[0][0] == 'Cp':  #任何一个Model 优先级都高于CP
            return True
        if pair_relate[1][0] == 'Cp':  #CP优先级低于任何一个Model
            return False
        # if nx.has_path(DominateRelation.G2, pair_relate[0][0] + '_' + str(pair_relate[0][1]), pair_relate[1][0] + '_' + str(pair_relate[1][1])):
        start = pair_relate[0][0] + '_' + str(pair_relate[0][1])
        end = pair_relate[1][0] + '_' + str(pair_relate[1][1])

        if start == end:  # example Dp_1 and Dp_1
            return False
        # if nx.bidirectional_dijkstra(DominateRelation.G2, start, end):
        try:
            if nx.has_path(DominateRelation.G2, start, end):
                return True
        except:
            return False

        # if pair_relate in DominateRelation.all_relation:
        #     return True


        return False