import networkx as nx
import matplotlib.pyplot as plt
import itertools

from netlistExtraction.sizeingruleslab.prototypes.alignschematic_alllib import fetchallInstances

targetCircuit = fetchallInstances(netlist_dir='C:/Users/ericwang/PycharmProjects/eda_dev/netlistExtraction/sizeingruleslab/conflict')



G1 = nx.Graph()
nodes = set()
edges = []
# nodes = nodes + subCircuit.pins
M_name = targetCircuit[0].name
for pin in targetCircuit[0].elements[0].pins.keys():
    nodes.add(M_name + pin)
    edges.append((M_name + pin, targetCircuit[0].elements[0].pins[pin]))
    nodes.add(targetCircuit[0].elements[0].pins[pin])
G1.add_nodes_from(nodes)
G1.add_edges_from(edges)


G2 = nx.Graph()
nodes2 = set()
edges2 = []
M_name2 = targetCircuit[2].name
for pin in targetCircuit[2].elements[0].pins.keys():
    nodes2.add(M_name + pin)
    edges2.append((M_name + pin, targetCircuit[2].elements[0].pins[pin]))
    nodes2.add(targetCircuit[2].elements[0].pins[pin])
G2.add_nodes_from(nodes)
G2.add_edges_from(edges)


is_isomorphic = nx.vf2pp_is_isomorphic(G2, G1, node_label=None)
print(is_isomorphic)
if is_isomorphic:
    map = nx.vf2pp_isomorphism(G2, G1, node_label=None)
    nx.draw(G1, with_labels=True)
    plt.show()

    print(map)
print("")