from netlistExtraction.sizeingruleslab.prototypes.CCM_NMOS.ccm_nmos import CcmNmos
from netlistExtraction.sizeingruleslab.prototypes.CML_NMOS.cml_nmos import CmlNmos
from netlistExtraction.sizeingruleslab.prototypes.CML_PMOS.cml_pmos import CmlPmos
from netlistExtraction.sizeingruleslab.prototypes.CP_NMOS.cp_nmos import CpNmos
from netlistExtraction.sizeingruleslab.prototypes.CP_PMOS.cp_pmos import CpPmos
from netlistExtraction.sizeingruleslab.prototypes.DP_NMOS.dp_nmos import DpNmos
from netlistExtraction.sizeingruleslab.prototypes.DP_NMOS_B.dp_nmos_b import DpNmosB
from netlistExtraction.sizeingruleslab.prototypes.DS_NMOS.ds_nmos import DsNmos
from netlistExtraction.sizeingruleslab.prototypes.FTCM_PMOS.ftcm_pmos import FtcmPmos
from netlistExtraction.sizeingruleslab.prototypes.LS_NMOS.ls_nmos import LsNmos
from netlistExtraction.sizeingruleslab.prototypes.LS_PMOS.ls_pmos import LsPmos
from netlistExtraction.sizeingruleslab.prototypes.SCM_NMOS.scm_nmos import ScmNmos
from netlistExtraction.sizeingruleslab.prototypes.SCM_NMOS_B.scm_nmos_b import ScmNmosB
from netlistExtraction.sizeingruleslab.prototypes.SCM_PMOS.scm_pmos import ScmPmos
from netlistExtraction.sizeingruleslab.prototypes.VR1_PMOS.vr1_pmos import Vr1Pmos
from netlistExtraction.sizeingruleslab.prototypes.VR2_PMOS.vr2_pmos import Vr2Pmos
from netlistExtraction.sizeingruleslab.prototypes.WSCCM_PMOS.wsccm_pmos import WsccmPmos


def initRulesWithB(sizingrules :[]):
    """有B的一套必须重新做一套  TODO考虑可能不是重做一套， 而是应该同时匹配"""


    sizingrules.append(DpNmosB())  # 在5tOpAmp有
    sizingrules.append(ScmNmosB())  #
    return sizingrules

def initAllSizingRules():
    sizingrules = []

    #NMOS  L1
    sizingrules.append(DpNmos())  # L1
    sizingrules.append(ScmNmos())  # L1
    sizingrules.append(LsNmos())    # L1
    sizingrules.append(CpNmos())  # L1
    sizingrules.append(CmlNmos()) # L1


    #PMOS L1
    sizingrules.append(ScmPmos())
    sizingrules.append(LsPmos())
    sizingrules.append(Vr1Pmos())
    sizingrules.append(Vr2Pmos())
    sizingrules.append(CpPmos())
    sizingrules.append(CmlPmos())

    # NMOS  L2
    sizingrules.append(CcmNmos())  # L2

    # PMOS  L2
    sizingrules.append(FtcmPmos())
    sizingrules.append(WsccmPmos())

    # NMOS  L3
    sizingrules.append(DsNmos())  # L3


    # initRulesWithB(sizingrules)
    return sizingrules


def printRes1_2(Res1, Res2):
    print("RES1 printing ...")
    for temp in Res1:
        print("The M1 - left or up one:")
        print(list(temp)[0])
        print("The M:")
        print(str(list(temp)[1]) + ", M is " + list(temp)[1].ruleNameMapped)
    print("=========================================")
    print("RES2 printing ...")
    for temp in Res2:
        print("The M2 - down or right one:")
        print(list(temp)[0])
        print("The M:")
        print(str(list(temp)[1]) + ", M is " + list(temp)[1].ruleNameMapped)

    print()

    print("Total module number for this schematic is: " + str(len(Res2)))

def print_final_M(final_m : []):
    num = 0
    for temp in final_m:
        if len(temp.names) > 1:
            num = num + 1
            print(str(num) + "  " + str(temp.names))
            print(temp.ruleNameMapped)

            # print(temp.)
    print("Total module number for this final module (after dominance filter) is: " + str(num))
