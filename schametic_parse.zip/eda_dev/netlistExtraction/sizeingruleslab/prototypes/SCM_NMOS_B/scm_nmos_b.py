from netlistExtraction.sizeingruleslab.prototypes.block import Block
import os

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class ScmNmosB(Block):
    mDict = {}
    ruleName = "ScmNmosB"

    currentDir = os.path.dirname(__file__)
    #Slolution2
    subCircuit = fetchInstances(netlist_dir=currentDir)

    mDict = {"M1": convertFromRawModule([subCircuit.elements[0]]), "M2": convertFromRawModule([subCircuit.elements[1]])}
    G = convertFromRawModule(subCircuit.elements).G

    M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])

    print("ScmNmosB initialized ...")


    def __init__(self):
        super().__init__()

if __name__ == "__main__":
    ScmNmosB()
