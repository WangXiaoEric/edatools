import pathlib
import shutil
from astri_eda import utils
from astri_eda.schema import Library, SpiceParser, Graph
from astri_eda.netlist_loader.read_spice import read_spice
import networkx as nx
import matplotlib.pyplot as plt


netlist_dir = ''
pdk_dir = 'pdks/FinFET14nm_Mock_PDK/'
config_path = pathlib.Path('align/config')
topology_dir = pathlib.Path('../../experiments/1_topology')
log_dir = '../../experiments'

working_dir = pathlib.Path.cwd().resolve()
pdk_dir = pathlib.Path(pdk_dir).resolve()

#extract .sp and .const.json files from dir
netlist_files,const_files = utils.extract_input_files(netlist_dir)
netlist = netlist_files[0]

#build logger
logger = utils.build_logger(log_dir)

subckt = netlist.stem.upper() #name of circuit
logger.info(f"Reading netlist: {subckt}")

#delete all files and folders in topology dir
shutil.rmtree(topology_dir, ignore_errors=True)
topology_dir.mkdir(exist_ok=True)

#extract circuits infromation from .sp file
lib = read_spice(netlist)

#convert subckt to graph
graph1 = Graph(lib[0])


# explicitly set positions
pos = {1: (0, 0), 2: (-1, 0.3), 3: (2, 0.17), 4: (4, 0.255), 5: (5, 0.03)}

options = {
    "font_size": 6,
    "node_size": 3000,
    "node_color": "white",
    "edgecolors": "black",
    "linewidths": 1,
    "width": 1,
    "node_color": "#A0CBE2",
    "with_labels": True
}

# nx.draw(graph1, nx.spring_layout(graph1), **options)
# nx.draw_networkx_edge_labels(graph1, pos=nx.spring_layout(graph1), **options)
nx.draw_networkx(graph1, pos=nx.spring_layout(graph1), **options)

plt.show()
print("Test")