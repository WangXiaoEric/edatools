class Block:

    def __init__(self):
        return
