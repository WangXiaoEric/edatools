import os

from netlistExtraction.sizeingruleslab.prototypes.block import Block

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *
from netlistExtraction.sizeingruleslab.prototypes.utils import convertFromRawModule, combineM1M2


class DpNmos(Block):
    mDict = {}
    ruleName = "DpNmos"
    #Slolution1
    # G = nx.Graph()
    # nodes = ['M1.d','M1.g','M1.s','M2.d','M2.g','M2.s','n1','n2','n3','n4','n5']
    # G.add_nodes_from(nodes)
    # edge = [('M1.d', 'n3'),('M1.g', 'n1'), ('M1.s', 'n5'),
    #         ('M2.d', 'n4'),  ('M2.g', 'n2'), ('M2.s', 'n5')]
    # G.add_edges_from(edge)
    currentDir = os.path.dirname(__file__)
    # Slolution2
    subCircuit = fetchInstances(netlist_dir=currentDir)


    mDict = {"M1": convertFromRawModule([subCircuit.elements[0]]), "M2": convertFromRawModule([subCircuit.elements[1]])}
    G = convertFromRawModule(subCircuit.elements).G

    M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])

    print("DpNmos initialized ...")


    def __init__(self):
        super().__init__()
