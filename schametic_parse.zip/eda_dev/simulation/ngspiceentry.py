import ctypes as ct
import numpy as np
import sys
import os
import platform
import subprocess as sp
import contextlib
from scipy.signal import lfilter,welch
import pylab


def ngspice_unbuffer_for_print(status, stream='stdout'):
    newline_chars = ['\r', '\n', '\r\n']
    stream = getattr(status, stream)
    with contextlib.closing(stream):
        while True:
            out = []
            last = stream.read(1)
            if last == '' and status.poll() is not None:
                break
            while last not in newline_chars:
                if last == '' and status.poll() is not None:
                    break
                out.append(last)
                last = stream.read(1)
            out = ''.join(out)
            yield out


def ngsim(sim_file):

   cppsim_home = os.getenv('CppSimHome')
   if cppsim_home == None:
       cppsim_home = os.getenv('CPPSIMHOME')
   if cppsim_home == None:
       home = os.getenv('HOME')
       if sys.platform == 'win32':
          default_cppsim_home = "C:\myApp\Spice64/bin/ngspice_con.exe"
          # default_cppsim_home = "C:\myApp\Spice64/bin/ngspice.exe"
       else:
          default_cppsim_home = "%s/CppSim" % (home)
       if os.path.isdir(default_cppsim_home):
          cppsim_home = default_cppsim_home

   cur_dir = os.getcwd()
   if sys.platform == 'win32':
      i = cur_dir.lower().find('\\simruns\\')
   else:
      i = cur_dir.lower().find('/simruns/')


   library_cell = cur_dir[i+9:1000]

   rp_base = default_cppsim_home  # run process.
   rp_arg1 = sim_file # File location.
   rp_arg2 = ""
   rp_arg3 = ""
   rp_arg4 = ""
   rp = [rp_base, rp_arg1]
   status = sp.Popen(rp, stdout=sp.PIPE, stderr=sp.STDOUT, universal_newlines=True)
   for line in ngspice_unbuffer_for_print(status):
       print(line)

   if status.returncode != 0:
       print('************** ERROR:  exited Ngspice run prematurely! ****************')
       sys.exit()

   # print("\n... running hspc ...\n")
   #
   # if sys.platform == 'win32':
   #     rp_base = '%s/HspiceToolbox/HSPC/bin/win32/hspc' % (cppsimshared_home)
   # else:
   #     rp_base = '%s/HspiceToolbox/HSPC/bin/hspc' % (cppsimshared_home)
   # rp_arg1 = 'netlist.ngsim'
   # rp_arg2 = 'simrun.sp'
   # rp_arg3 = sim_file
   # rp_arg4 = 'ngspice'
   # rp = [rp_base, rp_arg1, rp_arg2, rp_arg3, rp_arg4]
   # status = sp.Popen(rp, stdout=sp.PIPE, stderr=sp.STDOUT, universal_newlines=True)
   # for line in ngspice_unbuffer_for_print(status):
   #     print(line)
   #
   # if status.returncode != 0:
   #     print('************** ERROR:  exited Ngspice run prematurely! ****************')
   #     sys.exit()
   #
   # print('... running ngspice ...\n')
   #
   # if sys.platform == 'win32':
   #     rp_base = '%s/NGspice/NGspice_win32/bin/ngspice' % (cppsimshared_home)
   # elif sys.platform == 'darwin':
   #     rp_base = '%s/NGspice/NGspice_macosx/bin/ngspice' % (cppsimshared_home)
   # else:
   #     rp_base = '%s/NGspice/NGspice_glnxa64/bin/ngspice' % (cppsimshared_home)
   #
   # rp_arg1 = '-b'
   # rp_arg2 = '-r'
   # rp_arg3 = 'simrun.raw'
   # rp_arg4 = '-o'
   # rp_arg5 = 'simrun.log'
   # rp_arg6 = 'simrun.sp'
   # rp = [rp_base, rp_arg1, rp_arg2, rp_arg3, rp_arg4, rp_arg5, rp_arg6]
   #
   # status = sp.Popen(rp, stdout=sp.PIPE, stderr=sp.STDOUT, universal_newlines=True)
   # for line in ngspice_unbuffer_for_print(status):
   #     print(line)
   #
   # #########
   #
   # if sys.platform == 'win32':
   #     rp_base = '%s/Sue2/bin/win32/check_ngspice_logfile' % (cppsimshared_home)
   # else:
   #     rp_base = '%s/Sue2/bin/check_ngspice_logfile' % (cppsimshared_home)
   #
   # rp_arg1 = 'simrun.log'
   # rp = [rp_base, rp_arg1]
   #
   # status_scatch = sp.Popen(rp, stdout=sp.PIPE, stderr=sp.STDOUT, universal_newlines=True)
   #
   # #########
   #
   # if sys.platform == 'win32':
   #     rp_base = '%s/Sue2/bin/win32/ngspice_add_op_to_log' % (cppsimshared_home)
   # else:
   #     rp_base = '%s/Sue2/bin/ngspice_add_op_to_log' % (cppsimshared_home)
   #
   # rp = [rp_base]
   #
   # status_scratch = sp.Popen(rp, stdout=sp.PIPE, stderr=sp.STDOUT, universal_newlines=True)
   #
   # if status.returncode == 0:
   #     print('************** Ngspice run has completed ****************')

# ngsim()