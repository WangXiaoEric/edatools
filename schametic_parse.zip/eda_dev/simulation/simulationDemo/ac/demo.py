from simulation.ngspiceentry import *


for i in range(0, 1000):
    ngsim(sim_file ="C:/Users/ericwang/PycharmProjects/eda_dev/simulation/simulationDemo/ac/ac.sp")