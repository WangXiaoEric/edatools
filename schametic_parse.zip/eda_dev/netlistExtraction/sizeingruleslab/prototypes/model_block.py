class ModelBlock:
    def __init__(self):
        isBuildingBlock = False
        allowedTypes = False
        isBankable = False

        return
