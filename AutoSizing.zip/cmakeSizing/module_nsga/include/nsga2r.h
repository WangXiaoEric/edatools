#ifndef NSGA_H
#define NSGA_H
#ifdef __cplusplus
extern "C"
{
#endif
int nsgastart();

#ifdef __cplusplus
}
#endif

#endif