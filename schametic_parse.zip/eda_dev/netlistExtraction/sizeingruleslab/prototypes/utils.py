import copy

from netlistExtraction.sizeingruleslab.prototypes.BaseSizeModel import BaseSizeModel
import networkx as nx
import matplotlib.pyplot as plt



def convertFromRawModule(elemets):
    """从RawElements 转为 BaseSizeModel"""
    m = BaseSizeModel()
    m.rawElements = elemets
    m.names = []
    m.names_pins = [] # 存储name与PIN(G_D_S_B) Name序列 数据格式为 {M_name, []}
    m.names_graphs = [] # 存储name与subGraph(G_D_S_B)序列 数据格式为 {M_name, []}
    m.types = []

    m.G = nx.Graph()
    nodes = set()
    edges = []
    for ele in elemets:
        m.types.append(ele.model)
        m.names.append(ele.name)
        names_pin = []

        # 这里做成一个循环的， 支持多个rawElements的转化
        for pin in ele.pins.keys():
            nodes.add(ele.name + pin)
            # m.names_pins[ele.name].append(ele.name + pin)
            names_pin.append(ele.name + pin)
            # TODO考虑这个部分也采用set数据结构
            edges.append((ele.name + pin, ele.pins[pin]))
            nodes.add(ele.pins[pin])
        m.names_pins.append(names_pin)
        m.G.add_nodes_from(nodes)
        m.G.add_edges_from(edges)

    # all_subgraph_handler = []
    # #找到子连通图并与G D S B 对应起来
    # for subg in nx.connected_components(m.G):
    #     all_subgraph_handler.append(subg)
    #     # m.G.subgraph(i)
    #     # nx.draw(m.G.subgraph(i), with_labels=True)
    #     # plt.show()
    #     # print("=====")
    #
    # for names_pin in m.names_pins:
    #     names_graph = []
    #     for p_i in range(0, 4):
    #         subgraph_handler = findStrList(names_pin[p_i], all_subgraph_handler)
    #         # m.names_graph[key].append(subgraph_handler)
    #         names_graph.append(subgraph_handler)
    #     m.names_graphs.append(names_graph)
    populate_names_graphs(m)

    return m

def populate_names_graphs(m):
    """填充names_graphs数据 用作Graph的精准匹配"""
    m.names_graphs = []
    all_subgraph_handler = []
    # 找到子连通图并与G D S B 对应起来
    for subg in nx.connected_components(m.G):
        all_subgraph_handler.append(subg)
        # m.G.subgraph(i)
        # nx.draw(m.G.subgraph(i), with_labels=True)
        # plt.show()
        # print("=====")

    for names_pin in m.names_pins:
        names_graph = []
        for p_i in range(0, 4):
            subgraph_handler = findStrList(names_pin[p_i], all_subgraph_handler)
            # m.names_graph[key].append(subgraph_handler)
            names_graph.append(subgraph_handler)
        m.names_graphs.append(names_graph)


def filterM(M:BaseSizeModel, candidateM:list): #TODO
    """ 对于Module的匹配，最先过滤掉elements数量不一样的匹配 """
    res = []
    for temp_candidate in candidateM:
        # M.types == temp_candidate.types 可以直接判断数组是否相等
        if(nx.vf2pp_is_isomorphic(M.G, temp_candidate.G) and (M.types == temp_candidate.types)):
            res.append(temp_candidate)

    return res

def filterInF(list1, list_f):

    res = []
    for item_i in list1:
        for item_j in list_f:
            if item_i.names == item_j.names and item_i.ruleNameMapped == item_j.ruleNameMapped:
                res.append(item_i)
    return res

def removeInL1byL2(l1 :[], l2 :[]):
    res = copy.copy(l1)
    for item_l2 in l2:
        for item_l1 in l1:
            if item_l1.names == item_l2.names and item_l1.ruleNameMapped == item_l2.ruleNameMapped:
                res.remove(item_l1)

    return res

def mInList(M:BaseSizeModel, candidateM:list):
    for temp in candidateM:
        if temp.names == M.names and temp.ruleNameMapped == M.ruleNameMapped:
            return True
    return False


def combineM1M2(m_pos1: BaseSizeModel, m_pos2: BaseSizeModel):
    """同一个电路中的两个M进行合并，生成一个BaseSizeModel对象"""
    """合并这里是一个重点， 看对于Level2以上的是否也能够合并"""
    compare_pair = m_pos1.rawElements + m_pos2.rawElements  # TODO 先不管这个位置， 实在不行最后将其位置按照左上与右下锁死。
    # for one2one in list(itertools.permutations(targetCircuit.elements, 2)):

    G_M1_M2 = nx.Graph()
    G_M1_M2_nodes = set()
    G_M1_M2_edges = []
    # nodes = nodes + subCircuit.pins
    for ele in compare_pair:
        M_name = ele.name
        for pin in ele.pins.keys():
            G_M1_M2_nodes.add(M_name + pin)
            G_M1_M2_edges.append((M_name + pin, ele.pins[pin]))
            G_M1_M2_nodes.add(ele.pins[pin])

    G_M1_M2.add_nodes_from(G_M1_M2_nodes)
    G_M1_M2.add_edges_from(G_M1_M2_edges)

    M1_M2 = BaseSizeModel()

    M1_M2.G = G_M1_M2
    #TODO 思考多个rawElement后面如何进行管理  目前这里OK
    M1_M2.rawElements = compare_pair
    #TODO 考虑合并后M1与M2的 type  目前暂定与M1保持一致
    M1_M2.types = m_pos1.types + m_pos2.types
    M1_M2.names = m_pos1.names + m_pos2.names

    M1_M2.names_pins = M1_M2.names_pins + m_pos1.names_pins + m_pos2.names_pins #看起来这个是支持多个扩展的方法的

    # M1_M2.names_graphs = M1_M2.names_graphs + m_pos1.names_graphs + m_pos2.names_graphs
    populate_names_graphs(M1_M2)

    return M1_M2

def topologyAlreadyIN(m_pos1:BaseSizeModel, M_list:[]):
    """
    通过拓扑判断判断已经存在；
    通过
    """
    for temp in M_list:
        if len(temp.rawElements) == len(m_pos1.rawElements) and temp.types[0] == m_pos1.types[0]:
            ##同一个拓扑结构， 并且是同一个类型。 则视为已经存在
            is_isomorphic = nx.vf2pp_is_isomorphic(temp.G, m_pos1.G, node_label=None)
            if is_isomorphic:
                return True
    return False

def namePairAlreadyIN(m_pos1:BaseSizeModel, M_list:[], curRuleMapping: []):
    """
    通过LIST 名称判断已经存在；
    通过
    """
    for M in M_list:  #判断原先存在的
        if(listNominalEqual(m_pos1.names, M.names)):
            return True

    for M in curRuleMapping: #判断当前Rule中存在的
        if(listNominalEqual(m_pos1.names, M.names)):
            return True

    return False

def listNominalEqual(lsit1: [], list2: []):
    if len(lsit1) != len(list2):
        return False
    else:
        for item in lsit1:
            if item not in list2:
                return False
    return True

def isSizingRuleSomorphic(rule, G_M1_M2):

    # initJudge匹配整体是否MAP
    res = nx.vf2pp_is_isomorphic(rule.G, G_M1_M2.G, node_label=None)



    if res:
        # 测试数据

        # nx.draw(rule.G, with_labels=True)
        # plt.show()
        #
        # nx.draw(G_M1_M2.G, with_labels=True)
        # plt.show()

        # 测试数据
        #second judge - DGSB
        for i in range(len(rule.M1_M2.names_graphs)):
            for j in range(len(rule.M1_M2.names_graphs[i])):
                sub_graph_rule = rule.M1_M2.names_graphs[i][j]
                sub_graph_G = G_M1_M2.names_graphs[i][j]

                if nx.vf2pp_is_isomorphic(rule.G.subgraph(sub_graph_rule), G_M1_M2.G.subgraph(sub_graph_G), node_label=None):
                    continue
                else:
                    return False
    return res

def findStrList(str, str_lists):
    for str_list in str_lists:
        if str in str_list:
            return str_list
    return None


def bankGroupAndCombine(curRuleMapping_bankable: [], curRes1_bankable: [], curRes2_bankable: [], rule):
    #TODO 这里也存在过滤问题 譬如： ” MN11, M is MN9-ScmNmos“  与外面识别出来的 MN9 MN11 重复冲突问题
    targetM = []
    Res1 = []
    Res2 = []
    # targetM = targetM + curRuleMapping_bankable
    # Res1 = Res1 + curRes1_bankable
    # Res2 = Res2 + curRes2_bankable

    group_pair = {} # {key []} key的设计原则为  MP6MP5WsccmPmos
    #1 先分组，按照Leader的名称 并且ruleNameMapped = 'WsccmPmos' 类名称一致， ex.
    for idx, item in enumerate(curRuleMapping_bankable):
        if item.ruleNameMapped in ["ScmNmos", "ScmPmos", "LsNmos", "LsPmos"]:  # 两个L1 bank的处理
            tempKey = item.names[0] +  "-" + item.ruleNameMapped  #做标签唯一识别
        else :
            #  Ccm的处理拓展方式特殊
            if rule.ruleName in ["CcmNmos", "CcmPmos"]:
                tempKey = item.names[0] + item.names[2] + "-" + item.ruleNameMapped
            # 非CCM的处理
            else:
                tempKey = item.names[0] + item.names[1] + "-" + item.ruleNameMapped
        #包含key则新增
        if tempKey in group_pair:
            group_pair.get(tempKey).append(item)
        #不包含则新建
        else:
            group_pair[tempKey] = [item]

    print("====")
    #2 再合并。 同一组的进行合并， 合并bankable.  用convertFromRawModule 将群众pair组件起来， 用combine不断去组装起来；
    for key, pairList in group_pair.items():
        if len(pairList) < 2: #
            continue
        _M1 = None
        _M2 = None
        for idx, pair in enumerate(pairList):
            if idx == 0:
                if rule.ruleName in ["ScmNmos", "ScmPmos", "LsNmos", "LsPmos"]:
                    # _M1 = pair #默认为第一个
                    _M1 = convertFromRawModule([pair.rawElements[0]])  # 从第一个Pair把M1剥离出来
                    _M2 = convertFromRawModule([pair.rawElements[1]])  # 从第一个Pair把bankable的组件剥离出来，当作M2的第一个组件
                else:
                    #  Ccm的处理拓展方式特殊
                    if rule.ruleName in ["CcmNmos", "CcmPmos"]:  # CCM 与 CCMB的处理方式或许有所不同
                        _M1 = convertFromRawModule([pair.rawElements[0],pair.rawElements[2]])  # 从第一个Pair把M1剥离出来  TODO 考虑奇数延长
                        _M2 = convertFromRawModule([pair.rawElements[1],pair.rawElements[3]])  # 从第一个Pair把bankable的组件剥离出来，当作M2的第一个组件 TODO 考虑偶数延长
                    # 非CCM的处理
                    else:
                        # _M1 = pair #默认为第一个
                        _M1 = convertFromRawModule(pair.rawElements[0:2]) #从第一个Pair把M1剥离出来
                        _M2 = convertFromRawModule(pair.rawElements[2:4]) #从第一个Pair把bankable的组件剥离出来，当作M2的第一个组件  TODO 考虑更多 4可以进行 6 、 8 演唱
            else:  # 第二个以后只获取M2进行合并操作
                if rule.ruleName in ["ScmNmos", "ScmPmos", "LsNmos", "LsPmos"]:
                    _M2 = combineM1M2(_M2, convertFromRawModule(pair.rawElements[1:2]))
                else:
                    #  Ccm的处理拓展方式特殊
                    if rule.ruleName in ["CcmNmos", "CcmPmos"]:
                        _M2 = combineM1M2(_M2, convertFromRawModule([pair.rawElements[1],pair.rawElements[3]]))
                    else:
                        _M2 = combineM1M2(_M2, convertFromRawModule(pair.rawElements[2:4]))

        M1_M2 = combineM1M2(_M1, _M2)
        # M1_M2.ruleNameMapped = key
        M1_M2.ruleNameMapped = rule.ruleName

        #判定过滤，如果存在的话则不添加  TODO 待检查
        isExist = False
        for temp in curRuleMapping_bankable:
            if M1_M2.names == temp.names and M1_M2.ruleNameMapped == temp.ruleNameMapped:
                isExist = True
                break
        if not isExist:
            targetM.append(M1_M2)
            Res1.append([_M1, M1_M2])
            Res2.append([_M2, M1_M2])

    #3 组后返回三个最终结果， 同时考虑是否简化三个为1个结果 目的是返回 target M  PrintM1 PrintM2
    return targetM, Res1, Res2


def findClosure(M, R_plus):

    res = set()
    depletion_task = set()
    res.add(M)
    depletion_task.add(M)
    while depletion_task:
        #需要判定 depletion_item 与 M的左一致， 然后取出其右
        for depletion_item in depletion_task.copy():  # 添加Copy 为了解决set changed during iteration.
            for R in R_plus:
                if depletion_item.names == R[0].names and depletion_item.ruleNameMapped == R[0].ruleNameMapped:
                    res.add(R[1])
                    depletion_task.add(R[1])
            depletion_task.remove(depletion_item) #处理完毕后，将当前item移除掉


    return res

def baseSizeListIntersection(b1_list: [], b2_list: []):
    """求两个集合中 baseSize 对象的交集结果"""
    res = []
    for b1 in b1_list:
        for b2 in b2_list:
            if b1[0].names == b2[0].names and b1[0].ruleNameMapped == b2[0].ruleNameMapped\
                    and b1[1].names == b2[1].names and b1[1].ruleNameMapped == b2[1].ruleNameMapped:
                res.append(b2)  # append b1 or b2, either is right.
    return res

