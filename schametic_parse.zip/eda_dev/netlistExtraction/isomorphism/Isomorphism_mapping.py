import networkx as nx

G1 = nx.path_graph(8)
G2 = nx.path_graph(8)

is_isomorphic = nx.vf2pp_is_isomorphic(G2, G1, node_label=None)
print(is_isomorphic)




map = nx.vf2pp_isomorphism(G1, G2, node_label=None)
print(map)

map1 = nx.vf2pp_all_isomorphisms(G1, G2, node_label=None)
print(map1)

print("====")

