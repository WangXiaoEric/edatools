This is Astri EDA Simulation tool (AEST, based on NGspice) demo.
=================