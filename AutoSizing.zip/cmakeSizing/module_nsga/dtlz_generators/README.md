## Compilation
gcc -o dtlz3d dtlz3d_generator.c -lm

./dtlz3d
