from netlistExtraction.sizeingruleslab.prototypes.block import Block
import networkx as nx

from netlistExtraction.sizeingruleslab.prototypes.alignschematic import  *


class DpNmosB(Block):

    ruleName = "CcNmos"


    #Slolution1
    # G = nx.Graph()
    # nodes = ['M1.d','M1.g','M1.s','M2.d','M2.g','M2.s','n1','n2','n3','n4','n5']
    # G.add_nodes_from(nodes)
    # edge = [('M1.d', 'n3'),('M1.g', 'n1'), ('M1.s', 'n5'),
    #         ('M2.d', 'n4'),  ('M2.g', 'n2'), ('M2.s', 'n5')]
    # G.add_edges_from(edge)

    #Slolution2
    subCircuit = fetchInstances(netlist_dir='.\sizeingruleslab\prototypes\CCP_S_NMOS_B')
    G = nx.Graph()
    nodes = set()
    edges = []
    # nodes = nodes + subCircuit.pins
    for ele in subCircuit.elements:
        M_name = ele.name
        for pin in ele.pins.keys():
            nodes.add(M_name + pin)
            edges.append((M_name + pin, ele.pins[pin]))
            nodes.add(ele.pins[pin])

    G.add_nodes_from(nodes)
    G.add_edges_from(edges)
    pos_1Type = 'NMOS'
    pos_2Type = 'NMOS'

    # M1_M2 = combineM1M2(mDict["M1"], mDict["M2"])


    def __init__(self):
        super().__init__()
