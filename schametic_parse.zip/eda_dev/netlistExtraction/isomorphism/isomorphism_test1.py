from networkx.algorithms import isomorphism
import networkx as nx
from itertools import combinations
import matplotlib.pyplot as plt


#
#
# G1 = nx.path_graph(4)
# G2 = nx.path_graph(8)
# GM = isomorphism.GraphMatcher(G1, G2)
# result = GM.is_isomorphic()

# 搞不好要排列组合， 得到所有得graph. TODOpl.
# 必须同时具备edge连接，才能当作子图匹配；
def test_demo():
    G = nx.path_graph(5)  # or DiGraph, MultiGraph, MultiDiGraph, etc

    all_connected_graph = []

    NumberOfNodes = 5
    for r in range(2, NumberOfNodes+1):
        for SG in (G.subgraph(s) for s in combinations(nx.nodes(G), r)):
            if(nx.is_connected(SG)):
                nx.draw(SG,with_labels=True)
                plt.show()
                all_connected_graph.append(nx.nodes(SG))

    print(all_connected_graph)

# 后面再看根据node的数量 获取联通图的资料
def get_all_connected_subgraphs(G):
    """Get all connected subgraphs by a recursive procedure"""

    con_comp = [c for c in sorted(nx.connected_components(G), key=len, reverse=True)]

    def recursive_local_expand(node_set, possible, excluded, results, max_size):
        """
        Recursive function to add an extra node to the subgraph being formed
        """
        results.append(node_set)
        if len(node_set) == max_size:
            return
        for j in possible - excluded:
            new_node_set = node_set | {j}
            excluded = excluded | {j}
            new_possible = (possible | set(G.neighbors(j))) - excluded
            recursive_local_expand(new_node_set, new_possible, excluded, results, max_size)

    results = []
    for cc in con_comp:
        max_size = len(cc)

        excluded = set()
        for i in G:
            excluded.add(i)
            recursive_local_expand({i}, set(G.neighbors(i)) - excluded, excluded, results, max_size)

    results.sort(key=len)

    return results

test_demo()


G = nx.path_graph(5)
results = get_all_connected_subgraphs(G)
for el in results:
    print(el)
